#!/bin/bash
# ── NetPing Dashboard — Avvio (Mac / Linux) ──
echo ""
echo "  NetPing Dashboard"
echo "  ─────────────────────────────────────────"

# Controlla Python
if ! command -v python3 &> /dev/null; then
    echo "  [ERRORE] Python 3 non trovato."
    echo "  Installa da: https://www.python.org/downloads/"
    exit 1
fi

# Controlla/installa dipendenze
echo "  Installazione dipendenze..."
python3 -m pip install -q -r requirements.txt

echo ""
echo "  ✓ Avvio server su http://0.0.0.0:8000"
echo "  ✓ Apri il browser su: http://localhost:8000"
echo ""
echo "  Per accesso LAN: usa l'IP mostrato in alto nella dashboard."
echo "  Premi CTRL+C per fermare."
echo ""

python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
