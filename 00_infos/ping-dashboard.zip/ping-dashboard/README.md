# NetPing Dashboard

Dashboard web per monitorare la latenza di rete via ping in tempo reale.
Compatibile con **Windows** e **macOS** (nessun problema con Apple SIP).

---

## Requisiti

- **Python 3.11+** → https://www.python.org/downloads/
- Connessione internet (solo per caricare i font di Google la prima volta)

---

## Struttura del progetto

```
ping-dashboard/
├── main.py              # Backend FastAPI + WebSocket
├── requirements.txt     # Dipendenze Python
├── start_mac.sh         # Script avvio macOS/Linux
├── start_windows.bat    # Script avvio Windows
├── static/
│   └── index.html       # Frontend dashboard
└── README.md
```

---

## Avvio

### macOS / Linux

```bash
chmod +x start_mac.sh
./start_mac.sh
```

Poi apri il browser su: **http://localhost:8000**

### Windows

Doppio click su `start_windows.bat`  
oppure da terminale:

```cmd
start_windows.bat
```

Poi apri il browser su: **http://localhost:8000**

---

## Accesso da LAN

Il server si avvia già in modalità LAN (`0.0.0.0:8000`).  
L'IP locale è visibile direttamente nella dashboard in alto a destra.

Per accedere da un altro dispositivo nella stessa rete:

```
http://<IP_DEL_TUO_PC>:8000
```

### ⚠️ Firewall

| Sistema | Azione richiesta |
|---------|-----------------|
| **Windows** | Quando appare il popup di Windows Defender → clicca **Consenti accesso** |
| **macOS** | Quando appare il popup → clicca **Consenti**. In alternativa: Preferenze di Sistema → Sicurezza e Privacy → Firewall → aggiungi Python |

---

## Funzionalità

- Ping continuo con aggiornamento ogni secondo via WebSocket
- Grafico latenza in tempo reale (ultimi 60 campioni)
- Statistiche: Last / Avg / Min / Max / Sent / Loss%
- Log eventi con timestamp e stato (OK / SLOW / FAIL)
- Indicatore visivo: 🟢 Online / 🟡 Lento (>100ms) / 🔴 Offline
- Cross-platform: gestione automatica sintassi ping Windows/Mac
- Nessun database, tutto in memoria durante la sessione

---

## Personalizzazione

| Parametro | File | Variabile |
|-----------|------|-----------|
| Soglia "lento" (ms) | `static/index.html` | `SLOW_THRESHOLD = 100` |
| Punti nel grafico   | `static/index.html` | `MAX_CHART_POINTS = 60` |
| Porta server        | `main.py` / script avvio | `port=8000` |
| Righe log massime   | `static/index.html` | `MAX_LOG_ROWS = 200` |

---

## Dipendenze

| Libreria | Scopo |
|----------|-------|
| FastAPI | Backend web framework |
| Uvicorn | Server ASGI |
| Chart.js (CDN) | Grafico latenza |
| Google Fonts (CDN) | Rajdhani + Share Tech Mono |
