@echo off
echo.
echo   NetPing Dashboard
echo   -----------------------------------------
echo.

:: Controlla Python
python --version >nul 2>&1
if errorlevel 1 (
    echo   [ERRORE] Python non trovato.
    echo   Installa da: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo   Installazione dipendenze...
python -m pip install -q -r requirements.txt

echo.
echo   Avvio server su http://0.0.0.0:8000
echo   Apri il browser su: http://localhost:8000
echo.
echo   Per accesso LAN: usa l'IP mostrato in alto nella dashboard.
echo   Premi CTRL+C per fermare.
echo.

python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
pause
