import asyncio
import json
import platform
import re
import socket
from datetime import datetime
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

app = FastAPI(title="Ping Dashboard")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def root():
    return FileResponse("static/index.html")


@app.get("/info")
async def info():
    """Returns server IP and system info for LAN sharing."""
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except Exception:
        local_ip = "unavailable"
    return {
        "hostname": hostname,
        "local_ip": local_ip,
        "os": platform.system(),
        "port": 8000,
    }


def build_ping_command(host: str, count: int = 1) -> list:
    """Build OS-appropriate ping command."""
    os_name = platform.system()
    if os_name == "Windows":
        return ["ping", "-n", str(count), "-w", "2000", host]
    else:
        # macOS and Linux
        return ["ping", "-c", str(count), "-W", "2", host]


def parse_ping_output(output: str, os_name: str) -> dict:
    """Parse ping output for latency and packet loss."""
    result = {"rtt_ms": None, "success": False, "error": None}

    if os_name == "Windows":
        # Match "Tempo=XXms" or "time=XXms"
        match = re.search(r"[Tt]empo[<=](\d+)ms|[Tt]ime[<=](\d+)ms", output)
        if match:
            rtt = match.group(1) or match.group(2)
            result["rtt_ms"] = float(rtt)
            result["success"] = True
        elif "host non raggiungibile" in output.lower() or "unreachable" in output.lower():
            result["error"] = "Host unreachable"
        elif "timeout" in output.lower() or "scaduto" in output.lower():
            result["error"] = "Request timed out"
        else:
            result["error"] = "No response"
    else:
        # macOS / Linux: "time=12.3 ms"
        match = re.search(r"time[<=]([\d.]+)\s*ms", output)
        if match:
            result["rtt_ms"] = float(match.group(1))
            result["success"] = True
        elif "unreachable" in output.lower():
            result["error"] = "Host unreachable"
        elif "timeout" in output.lower() or "no answer" in output.lower():
            result["error"] = "Request timed out"
        else:
            result["error"] = "No response"

    return result


async def do_ping(host: str) -> dict:
    """Execute a single ping and return parsed result."""
    os_name = platform.system()
    cmd = build_ping_command(host, count=1)
    timestamp = datetime.now().strftime("%H:%M:%S")

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=5.0)
        output = stdout.decode(errors="replace") + stderr.decode(errors="replace")
        parsed = parse_ping_output(output, os_name)
        parsed["timestamp"] = timestamp
        parsed["host"] = host
        return parsed
    except asyncio.TimeoutError:
        return {"success": False, "rtt_ms": None, "error": "Process timeout", "timestamp": timestamp, "host": host}
    except FileNotFoundError:
        return {"success": False, "rtt_ms": None, "error": "ping command not found", "timestamp": timestamp, "host": host}
    except Exception as e:
        return {"success": False, "rtt_ms": None, "error": str(e), "timestamp": timestamp, "host": host}


@app.websocket("/ws/ping")
async def websocket_ping(websocket: WebSocket):
    await websocket.accept()
    pinging = False
    current_task = None

    async def ping_loop(host: str):
        nonlocal pinging
        while pinging:
            result = await do_ping(host)
            await websocket.send_text(json.dumps({"type": "ping_result", "data": result}))
            await asyncio.sleep(1)

    try:
        while True:
            message = await websocket.receive_text()
            data = json.loads(message)
            action = data.get("action")

            if action == "start":
                host = data.get("host", "").strip()
                if not host:
                    await websocket.send_text(json.dumps({"type": "error", "message": "Host is required"}))
                    continue

                # Stop any existing ping loop
                pinging = False
                if current_task and not current_task.done():
                    current_task.cancel()
                    try:
                        await current_task
                    except asyncio.CancelledError:
                        pass

                pinging = True
                await websocket.send_text(json.dumps({"type": "started", "host": host}))
                current_task = asyncio.create_task(ping_loop(host))

            elif action == "stop":
                pinging = False
                if current_task and not current_task.done():
                    current_task.cancel()
                    try:
                        await current_task
                    except asyncio.CancelledError:
                        pass
                await websocket.send_text(json.dumps({"type": "stopped"}))

    except WebSocketDisconnect:
        pinging = False
        if current_task and not current_task.done():
            current_task.cancel()
    except Exception as e:
        pinging = False
        try:
            await websocket.send_text(json.dumps({"type": "error", "message": str(e)}))
        except Exception:
            pass
